//
//  ViewController.swift
//  Birhanu-Bishaw_COMP2125-003_Final-Term
//
//  Created by Birhanu Bishaw on 2020-07-26.
//  Copyright © 2020 Birhanu Bishaw. All rights reserved.
//

import UIKit

class ProductDetailsViewController: UIViewController {
    
    // outlets
    @IBOutlet weak var txtApplianceId: UITextField!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtPricePerItem: UITextField!
    @IBOutlet weak var txtQuantity: UITextField!
    
    // local variables
    var name: String = ""
    var pricePerItem: Double = 0.0
    var quantity: Int = 0
    var output: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    // actions
    @IBAction func btnNextTapped(_ sender: UIButton) {
        //performSegue(withIdentifier: "segueToUserDetails", sender: self)
    }
    
    // pass username to the client view controller
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! UserDetailsViewController
        name = txtName.text!
        pricePerItem = Double(txtPricePerItem.text!)!
        quantity = Int(txtQuantity.text!)!
        var tot:Double = 0.0
        tot = pricePerItem * Double(quantity)
        output = "1. Item name: "+name+"\n2. Quantity:  "+String(quantity)+"\n3. Price: "+"$"+String(pricePerItem)+"\n4. Sub-total: "+"$"+String(tot)
        vc.summary = output
    }
    
}

