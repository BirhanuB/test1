//
//  ViewController.swift
//  Birhanu-Bishaw_COMP2125-003_Final-Term
//
//  Created by Birhanu Bishaw on 2020-07-26.
//  Copyright © 2020 Birhanu Bishaw. All rights reserved.
//

import UIKit

class ProductDetailsViewController: UIViewController {
    
    // outlets
    @IBOutlet weak var txtApplianceId: UITextField!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtPricePerItem: UITextField!
    @IBOutlet weak var txtQuantity: UITextField!
    
    // local variables
    var name: String = ""
    var pricePerItem: Double = 0.0
    var quantity: Int = 0
    var output: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    // actions
    @IBAction func btnNextTapped(_ sender: UIButton) {

    }
    
    // pass required info with summary to the user details view controller after validating quantity
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! UserDetailsViewController
        name = txtName.text!
        pricePerItem = round(Double(txtPricePerItem.text!)! * 100)/100
        quantity = Int(txtQuantity.text!)!
        // check if quantity is valid
        if (quantity < 1 || quantity > 3) {
            output = "Invalid quantity! \nQuantity should be min 1 and max 3. Please go back and correct it"
        }
        else {
            var subTot:Double = 0.0
            subTot = round(pricePerItem * Double(quantity) * 100)/100
            output = "1. Item name: "+name+"\n2. Quantity: "+String(quantity)+"\n3. Price: "+"$"+String(pricePerItem)+"\n4. Sub-total: "+"$"+String(subTot)
            vc.subTotal = subTot
        }
        vc.summary = output
    }
    
}

