//
//  ViewController.swift
//  Birhanu-Bishaw_COMP2125-003_Final-Term
//
//  Created by Birhanu Bishaw on 2020-07-26.
//  Copyright © 2020 Birhanu Bishaw. All rights reserved.
//

import UIKit

class ProductDetailsViewController: UIViewController {
    
    // outlets
    @IBOutlet weak var txtApplianceId: UITextField!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtPricePerItem: UITextField!
    @IBOutlet weak var txtQuantity: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    // actions
    @IBAction func btnNextTapped(_ sender: UIButton) {
    }
    
}

