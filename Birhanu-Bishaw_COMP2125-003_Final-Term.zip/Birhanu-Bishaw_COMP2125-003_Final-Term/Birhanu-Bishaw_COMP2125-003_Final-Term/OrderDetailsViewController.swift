//
//  OrderDetailsViewController.swift
//  Birhanu-Bishaw_COMP2125-003_Final-Term
//
//  Created by Birhanu Bishaw on 2020-07-26.
//  Copyright © 2020 Birhanu Bishaw. All rights reserved.
//

import UIKit

class OrderDetailsViewController: UIViewController {

    // outlets
    @IBOutlet weak var txtOrderId: UITextField!
    @IBOutlet weak var txtUName: UITextField!
    @IBOutlet weak var txtTotalPrice: UITextField!
    @IBOutlet weak var txtSaveOutput: UITextView!
    
    // local variables
    var ordId: Int = 0
    var usName: String = ""
    var total: Double = 0.0

    override func viewDidLoad() {
        super.viewDidLoad()
        txtOrderId.text = String(ordId)
        txtUName.text = usName
        txtTotalPrice.text = "$"+String(total)
        // Do any additional setup after loading the view.
    }
    
    // actions
    @IBAction func btnSaveTapped(_ sender: UIButton) {
        txtSaveOutput.text = "Thanks for placing order, " + usName
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
