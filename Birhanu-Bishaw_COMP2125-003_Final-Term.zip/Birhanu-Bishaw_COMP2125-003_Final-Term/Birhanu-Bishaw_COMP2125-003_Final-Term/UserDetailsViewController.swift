//
//  UserDetailsViewController.swift
//  Birhanu-Bishaw_COMP2125-003_Final-Term
//
//  Created by Birhanu Bishaw on 2020-07-26.
//  Copyright © 2020 Birhanu Bishaw. All rights reserved.
//

import UIKit

class UserDetailsViewController: UIViewController {
    
    // outlets
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtAddress: UITextField!
    @IBOutlet weak var txtNextOutput: UITextView!
    
    // local variables
    var summary: String = ""
    var ordId = Int.random(in: 10...99)
    var subTotal: Double = 0.0

    override func viewDidLoad() {
        super.viewDidLoad()
        txtNextOutput.text = summary
        // Do any additional setup after loading the view.
    }
    
    // actions
    @IBAction func btnSubmitTapped(_ sender: UIButton) {

    }
    
    // pass order id, user name and total price to the order details view controller
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! OrderDetailsViewController
        vc.ordId = ordId
        vc.usName = txtUserName.text!
        var total:Double = 0.0
        total = round(subTotal * 1.13 * 100)/100
        vc.total = total
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
